var c = document.querySelector("#cookies");

function byebtn(element) {
    c.remove();
}